'''
Created on 15-Mar-2016

@author: parkar_s
'''
min_ratings = 0
max_ratings = 20

popular_min_rt = 3
popular_max_rt = 5
