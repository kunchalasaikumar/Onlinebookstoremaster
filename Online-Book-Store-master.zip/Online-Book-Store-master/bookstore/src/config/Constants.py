'''
Created on 17-Jul-2016

@author: Dell
'''


class CartOperations():

    def __init__(self):
        self.ADD = 'add'
        self.REMOVE = 'delete'
        self.UPDATE = 'update'
