'''
Created on 14-Mar-2016

@author: parkar_s
'''
HOST = 'localhost'
DB_USER = 'root'
DB_NAME = 'bookstore'
DB_PASSWORD = 'root'
DB_CHARSET = 'utf8mb4'