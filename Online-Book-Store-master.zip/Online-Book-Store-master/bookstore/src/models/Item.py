'''
Created on 14-Mar-2016

@author: parkar_s
'''

class Item(object):
    '''
    classdocs
    '''


    @abstractmethod
    
        