angular.module("bookStore").constant("SideMenu",  {"name":"Menu", "submenu":[{
	"name" : "Menu",
	"submenu" : [],
	"root" : true
}, {
	"name" : "Categories",
	"submenu" : [],
	"root" : true
}, {
	"name" : "My orders",
	"submenu" : [],
	"root" : false
}, {
	"name" : "Profile",
	"submenu" : [],
	"root" : false
}, {
	"name" : "Gift Cards",
	"submenu" : [],
	"root" : false
}, {
	"name" : "Wish list",
	"submenu" : [],
	"root" : false
}]} )