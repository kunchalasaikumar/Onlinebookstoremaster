var app=angular.module("bookStore",['ngRoute','ui.bootstrap','ngSanitize']);
