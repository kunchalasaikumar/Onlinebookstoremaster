/**
 * 
 */
var config={
	"vesrion":"1.0",
	"endPointBaseUrl":"http://127.0.0.1:5000/",
	"version":"v1.0",
	"defaultOffset":0,
	"logPageLimit":5,
	"paginationListLimit":5,
	"baseUrl":"/api/v1.0/"
}