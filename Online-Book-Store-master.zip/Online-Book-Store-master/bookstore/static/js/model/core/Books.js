/**
 * 
 */

function Book(isbn, title, authors, publisher, yop, available_copies, price, format, keywords, subject,category,image_loc){
	this.isbn = isbn
	this.title = title
	this.authors = authors
	this.publisher = publisher
	this.yop = yop
	this.available_copies = available_copies
	
	this.price = price
	this.format = format
	this.keywords = keywords
	this.Subject = subject
	this.category = Category()
	
	this.image_loc = image_loc
	
}