/**
 * 
 */function Contact(fName, lName, eMail, phoneNum){
	 this.name = fName +lName
	 this.email = eMail
	 this.phone_num = phoneNum
 }