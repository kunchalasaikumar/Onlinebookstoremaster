function Order(method, city, state, zipcode, street, building, room_no){
	this.country = country
	this.city = city
	this.state = state
	this.zipcode = zipcode
	this.street = street
	this.building = building || null
	
	this.room_no = room_no  || null
	
}