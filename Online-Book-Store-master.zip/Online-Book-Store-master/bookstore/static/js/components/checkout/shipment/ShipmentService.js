	angular.module("bookStore").service("ShipmentService",function($q, $http, DataService){
		endPoint="books"
		dataService= DataService
	

})
