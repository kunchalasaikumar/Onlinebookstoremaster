angular.module("bookStore").controller("popularBooksCtrl", ['$scope','BookService',function($scope, BookService){
	
}])