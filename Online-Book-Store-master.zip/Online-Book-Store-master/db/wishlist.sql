insert into wishlist(user_id, wishlist_id,isbn,name) values('adit21','anbhd3455bg','978-0452789030','Adits wishlist'),
	('adit21','kiuer7rer','978-1401312455','Adits wishlist'),
	('adit21','3kh324h','978-1476762932','Adits wishlist'),
	('adit21','lj34595','978-1848160930','Adits wishlist'),
	('adit21','mj3345','978-0465784725','Adits wishlist'),
	('adit21','gh4k5n5k','978-0374275631','Adits wishlist'),
	('adit21','748484nn','978-0452299030','Adits wishlist')