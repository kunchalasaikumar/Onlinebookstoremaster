INSERT INTO Feedback (Login_id,ISBN,Score,Date,Short_text) VALUES ('oman2483','978-1401312855',8,'2015-12-12','Mind over matter on this one guys, if you"re really determined, you can accomplish anything. if you can see it, you can achieve it.')
,('hris79','978-1401312855', 8, '2015-12-12', 'I Came: The title of this book was very deceptive. I found each image to be uniquely arousing.')
,('ardy46329','978-1476764832', 5, '2015-12-12', 'Directions unclear,  Would not recommend.')
,('elge4953','978-0812993547', 10,'2015-12-12', 'Such a terrific reference work! But with so many terrific random digits, it"s a shame they didn"t sort them')
,('uBay81', '978-1400033805', 10, '2015-12-12', 'While the printed version is good')
,('eman30', '978-0452299030', 7, '2015-12-12', 'Lousy even for a prank gift')
,('niel553', '978-0465054725', 6, '2015-12-12', 'For anyone who read "A Million Random Digits," feel free to skip this book.')
,('oner94', '978-1848162730', 6,'2015-12-12', 'The world would be more mellow, more joyful, more productive without so many dicks ruining the calm')
,('ings9871', '978-0062409850', 10, '2015-12-12', 'The author is a good');